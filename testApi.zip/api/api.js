const express = require('express');
const router = express.Router();
const controller = require('../controllers/user');

const serverName = "http://sadmin.choira.io:4000/api/download/";


router.get('/users', function(req,res,next){
     
});